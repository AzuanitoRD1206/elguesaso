﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CrudAudiovisuales.models;

namespace CrudAudiovisuales.Controllers
{
    public class RentadevolucionsController : Controller
    {
        private readonly AudiovisualesContext _context;

        public RentadevolucionsController(AudiovisualesContext context)
        {
            _context = context;
        }

        // GET: Rentadevolucions
        public async Task<IActionResult> Index()
        {
            var audiovisualesContext = _context.Rentadevolucions.Include(r => r.Empleado).Include(r => r.Equipo).Include(r => r.Usuario);
            return View(await audiovisualesContext.ToListAsync());
        }

        // GET: Rentadevolucions/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Rentadevolucions == null)
            {
                return NotFound();
            }

            var rentadevolucion = await _context.Rentadevolucions
                .Include(r => r.Empleado)
                .Include(r => r.Equipo)
                .Include(r => r.Usuario)
                .FirstOrDefaultAsync(m => m.NoPrestamo == id);
            if (rentadevolucion == null)
            {
                return NotFound();
            }

            return View(rentadevolucion);
        }

        // GET: Rentadevolucions/Create
        public IActionResult Create()
        {
            ViewData["EmpleadoId"] = new SelectList(_context.Empleados, "Id", "Id");
            ViewData["EquipoId"] = new SelectList(_context.Equipos, "Id", "Id");
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Id");
            return View();
        }

        // POST: Rentadevolucions/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("NoPrestamo,EmpleadoId,EquipoId,UsuarioId,FechaPrestamo,FechaDevolucion,Comentario,Estado")] Rentadevolucion rentadevolucion)
        {
            if (ModelState.IsValid)
            {
                _context.Add(rentadevolucion);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmpleadoId"] = new SelectList(_context.Empleados, "Id", "Id", rentadevolucion.EmpleadoId);
            ViewData["EquipoId"] = new SelectList(_context.Equipos, "Id", "Id", rentadevolucion.EquipoId);
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Id", rentadevolucion.UsuarioId);
            return View(rentadevolucion);
        }

        // GET: Rentadevolucions/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Rentadevolucions == null)
            {
                return NotFound();
            }

            var rentadevolucion = await _context.Rentadevolucions.FindAsync(id);
            if (rentadevolucion == null)
            {
                return NotFound();
            }
            ViewData["EmpleadoId"] = new SelectList(_context.Empleados, "Id", "Id", rentadevolucion.EmpleadoId);
            ViewData["EquipoId"] = new SelectList(_context.Equipos, "Id", "Id", rentadevolucion.EquipoId);
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Id", rentadevolucion.UsuarioId);
            return View(rentadevolucion);
        }

        // POST: Rentadevolucions/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("NoPrestamo,EmpleadoId,EquipoId,UsuarioId,FechaPrestamo,FechaDevolucion,Comentario,Estado")] Rentadevolucion rentadevolucion)
        {
            if (id != rentadevolucion.NoPrestamo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(rentadevolucion);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RentadevolucionExists(rentadevolucion.NoPrestamo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["EmpleadoId"] = new SelectList(_context.Empleados, "Id", "Id", rentadevolucion.EmpleadoId);
            ViewData["EquipoId"] = new SelectList(_context.Equipos, "Id", "Id", rentadevolucion.EquipoId);
            ViewData["UsuarioId"] = new SelectList(_context.Usuarios, "Id", "Id", rentadevolucion.UsuarioId);
            return View(rentadevolucion);
        }

        // GET: Rentadevolucions/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Rentadevolucions == null)
            {
                return NotFound();
            }

            var rentadevolucion = await _context.Rentadevolucions
                .Include(r => r.Empleado)
                .Include(r => r.Equipo)
                .Include(r => r.Usuario)
                .FirstOrDefaultAsync(m => m.NoPrestamo == id);
            if (rentadevolucion == null)
            {
                return NotFound();
            }

            return View(rentadevolucion);
        }

        // POST: Rentadevolucions/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Rentadevolucions == null)
            {
                return Problem("Entity set 'AudiovisualesContext.Rentadevolucions'  is null.");
            }
            var rentadevolucion = await _context.Rentadevolucions.FindAsync(id);
            if (rentadevolucion != null)
            {
                _context.Rentadevolucions.Remove(rentadevolucion);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RentadevolucionExists(int id)
        {
          return (_context.Rentadevolucions?.Any(e => e.NoPrestamo == id)).GetValueOrDefault();
        }
    }
}
